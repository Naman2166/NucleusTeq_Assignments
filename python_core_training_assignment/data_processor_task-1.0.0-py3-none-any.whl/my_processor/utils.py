import re


class InvalidMemberDataError(Exception):
    """
    Custom exception for invalid member data
    """
    pass


def validate_email(email):
    """
    Validating email address using regular expression
    """
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"

    if not re.match(pattern, email):
        raise InvalidMemberDataError(f"Invalid email: {email}")

    return True


def validate_phone(phone):
    """
    Validating phone number using regular expression
    """
    pattern = r"^[6-9][0-9]{9}$"

    if not re.match(pattern, phone):
        raise InvalidMemberDataError(f"Invalid Indian phone number: {phone}")

    return True


def clean_text(value):
    """
    Remove unnecessary spaces from text
    """
    return value.strip()