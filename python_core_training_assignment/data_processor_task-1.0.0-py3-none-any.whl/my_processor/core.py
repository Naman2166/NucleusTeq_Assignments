from .utils import validate_email, validate_phone, clean_text, InvalidMemberDataError


class Member:
    """
    This class represents a member
    """

    def __init__(self, name, email, phone):
        self.name = clean_text(name)
        self.email = clean_text(email)
        self.phone = clean_text(phone)

    def validate_member(self):
        """
        Validate member information
        """
        if not self.name:
            raise InvalidMemberDataError("Member name cannot be empty")

        validate_email(self.email)
        validate_phone(self.phone)

        return True

    def __str__(self):
        return (
            f"Member(name='{self.name}', "
            f"email='{self.email}', "
            f"phone='{self.phone}')"
        )